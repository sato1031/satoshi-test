window.jQuery = window.$ = require('jquery');
var dt      = require('datatables.net-dt')();
var bs      = require('bootstrap');
var p      = require('popper');
var Typeahead = require('typeahead');

